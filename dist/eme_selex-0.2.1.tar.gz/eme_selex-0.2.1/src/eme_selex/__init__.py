"""Perform k-mer abundance analysis in DNA sequences"""

__version__ = "0.2.1"