"""Perform k-mer abundance analysis in DNA sequences"""

__version__ = "0.3.1"